 <?php  
//if(isset($_POST['submit']))
if($_POST)
{
mysql_connect("localhost","root","") or die(mysql_error());

mysql_select_db("ases1") or die(mysql_error());

 

  $doc_no=$_POST['doc_no'];
  $doc_name=$_POST['doc_name'];
  $is_active=$_POST['is_active'];
  
 
try{
 $flag=0;
 if(mysql_query("INSERT INTO mst_doc_ctrl(doc_no,doc_name,is_active) VALUES('$doc_no','$doc_name','$is_active')"))
		{
		$flag=1;
		echo "Form Submitted Succesfully";}
else if($flag==0)
{
	throw new Exception(" Already Exits");}
}
catch (Exception $e) {
    echo   $e->getMessage() ;
} 
 }

?>