 $(document).ready(function(){
 $('#submit').click(function(){
  alert("we have qq");
  });
});
