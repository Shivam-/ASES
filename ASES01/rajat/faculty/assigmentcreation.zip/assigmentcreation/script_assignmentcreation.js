





$(document).ready(function(){

var t=0;

var no = $("#question_no").val();
$("#nextbtn").click(function(){

var question_no = $("#question_no").val();
var question_name = $("#question_name").val();
var max_marks = $("#max_marks").val();

 var l;
   // Returns successful data submission message when the entered information is stored in database.
var dataString = 'question_no1='+ question_no + '&question_name1='+ question_name + '&max_marks1='+ max_marks;
var datano='no='+no;
alert(dataString);
alert(datano);
if(question_no==''||question_name==''||max_marks=='') 
{    
alert("Please Fill All Fields");
}
else
{
$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
 var h=data;
 a(h);
   $('#faltu').val(data);
}


});
 t1=$('#faltu').val();
t1++;
alert("value of t"+t1);

alert("value of q"+question_no);
alert(t1==question_no);
/*{
alert("if ke andar");
	// AJAX Code To entry Form.
/*$.ajax({
type: "POST",
url: "entry_assignmentcreation.php",
data: dataString,
cache: false,
success: function(result){
alert(result);

}

});
}*/
}

var temp=$("#question_no").val();
var len=temp.length;
var arr=temp.split('.');
var last=arr[arr.length-1];
if(last>0)
{last++;}
var newno="";
for(i=0;i<arr.length-1;i++)
{
newno+=arr[i]+".";
}
newno=newno+last;
$("#question_no").val(newno);

});

function a(data)
{
alert(data);

var question_no = $("#question_no").val();
alert(question_no);
if(data===question_no)
{
alert("alter");
}
}

});
 