$(document).ready(function(){


// subdec
$("#subdec").click(function(){
var btn="subdec";

var question_no = $("#question_no").val();
var question_name = $("#question_name").val();
var max_marks = $("#max_marks").val();
 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'question_no1='+ question_no + '&question_name1='+ question_name + '&max_marks1='+ max_marks;
var datano='no='+question_no;
//alert("dd:"+dataString);
//alert("datano:"+datano);

$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
 var h=data;
 //alert("php:"+h);
 matchno(h,dataString,btn);
   $('#faltu').val(data);
}


});
 

});


// subadd
$("#subadd").click(function(){
var btn="subadd";

var question_no = $("#question_no").val();
var question_name = $("#question_name").val();
var max_marks = $("#max_marks").val();
 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'question_no1='+ question_no + '&question_name1='+ question_name + '&max_marks1='+ max_marks;
var datano='no='+question_no;
//alert("dd:"+dataString);
//alert("datano:"+datano);
if(question_no==''||question_name==''||max_marks=='') 
{    
alert("Please Fill All Fields");
}
else
{
$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
 var h=data;
 //alert("php:"+h);
 matchno(h,dataString,btn);
   $('#faltu').val(data);
}


});
 
}
});



// prebtn
$("#prebtn").click(function(){
var btn="pre";

var question_no = $("#question_no").val();
var question_name = $("#question_name").val();
var max_marks = $("#max_marks").val();
  


 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'question_no1='+ question_no + '&question_name1='+ question_name + '&max_marks1='+ max_marks;
var datano='no='+question_no;
//alert("dd:"+dataString);
//alert("datano:"+datano);


$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
 var h=data;
 //alert("php:"+h);
 matchno(h,dataString,btn);
   $('#faltu').val(data);
}


});
 

});



// nextbtn
$("#nextbtn").click(function(){
var btn ="next";
var question_no = $("#question_no").val();
var question_name = $("#question_name").val();
var max_marks = $("#max_marks").val();
 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'question_no1='+ question_no + '&question_name1='+ question_name + '&max_marks1='+ max_marks;
var datano='no='+question_no;
//alert("dd:"+dataString);
//alert("datano:"+datano);
if(question_no==''||question_name==''||max_marks=='') 
{    
alert("Please Fill All Fields");
}
else
{
$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
 var h=String.trim(data);
 //alert("php:"+h);
 matchno(h,dataString,btn);
   $('#faltu').val(data);
}


});
 
}
});

// no exist or not in database

function matchno(data,dataString,btn)
{
var question_no = $("#question_no").val();
var question_no=question_no.toString();
//alert("a:"+question_no);
//alert("php:"+String.trim(data));
//alert(String.trim(data)==question_no)
if(String.trim(data)==question_no)
{
//alert("a:php"+String.trim(data));
if(question_no!=''||question_name!=''||max_marks!='') 
{ 
alter(dataString);
}
//alert(btn);
if(btn=="next")
{
increaseno();
//alert("now");
var question_no = $("#question_no").val();
var datano='no='+question_no;
//alert(datano);
findshow(datano,dataString,btn);
}
if(btn=="subadd")
{
subadd();
//alert("now");
var question_no = $("#question_no").val();
var datano='no='+question_no;
//alert(datano);
findshow(datano,dataString,btn);
}
if(btn=="pre")
{
prepart();
//alert("now");
var question_no = $("#question_no").val();
var datano='no='+question_no;
//alert(datano);
findshow(datano,dataString,btn);
}
if(btn=="subdec")
{
subdec();
//alert("now");
var question_no = $("#question_no").val();
var datano='no='+question_no;
//alert(datano);
findshow(datano,dataString,btn);
}
}
else
{
//alert("else ke andar");
	// AJAX Code To entry Form.
$.ajax({
type: "POST",
url: "entry_assignmentcreation.php",
data: dataString,
cache: false,
success: function(result){
alert(result);

}

});
if(btn=="next")
{
$("#question_name").val("");
increaseno();
}
if(btn=="subadd")
{
$("#question_name").val("");
subadd();
}
}



}

function findshow(datano,dataString,btn)
{
$.ajax({
type: "POST",
url: "findno.php",
data:datano,
cache: false,
success: function(data){
 
var h=String.trim(data);
 //alert("php:"+h);
 matchshow(h,dataString,btn);
   $('#faltu').val(data);
}


});
}

function matchshow(data,dataString,btn)
{
var question_no = $("#question_no").val();
//alert("a:"+question_no);
if(String.trim(data)==question_no)
{
//alert("a:php"+String.trim(data));


//alert(btn);
var question_no = $("#question_no").val();
var datano='no='+question_no;
show(datano);
}
else
{
$("#question_name").val("");
}

}
// to next increase no
function increaseno()
{
var temp=$("#question_no").val();
var len=temp.length;
var arr=temp.split('.');
var last=arr[arr.length-1];
if(last>0)
{last++;}
var newno="";
for(i=0;i<arr.length-1;i++)
{
newno+=arr[i]+".";
}
newno=newno+last;
$("#question_no").val(newno);

}

// for pre

function prepart()
{
////alert($("#question_no").val()+".1");
var temp=$("#question_no").val();
var len=temp.length;
var arr=temp.split('.');
var last=arr[arr.length-1];
if(last>1)
{last--;}
var newno="";
for(i=0;i<arr.length-1;i++)
{
newno+=arr[i]+".";
}
newno=newno+last;
$("#question_no").val(newno);
}

function subadd()
{
////alert($("#question_no").val()+".1");
var temp=$("#question_no").val()+".1";
$("#question_no").val(temp);
}



function subdec()
{
////alert($("#question_no").val()+".1");
var temp=$("#question_no").val();

var f=temp.length;
if(f!=1)
{
$("#question_no").val(temp.substring(0,f-2));}
}

// alter
function alter(dataString)
{
$.ajax({
type: "POST",
url: "alter_assignmentcreation.php",
data: dataString,
cache: false,
success: function(result){
alert(result);

}

});
}

// for show
function show(dataString)
{
$.ajax({
type: "POST",
url: "show_question.php",
data: dataString,
cache: false,
success: function(result){
showform(result);
alert(result);

}

});

}

// to print in

function showform(result)
{
//alert("aa gaya"+result);
var seprate=result.split('##');
i=0;
while(i<seprate.length)
{
var x=seprate[i].toString();
var x=String.trim(x);
$("#question_no").val(x);
i++;
var x=seprate[i].toString();
$("#question_name").val(x);
i++;
var x=seprate[i].toString();
$("#max_marks").val(x);
i++;
}

}
});
 