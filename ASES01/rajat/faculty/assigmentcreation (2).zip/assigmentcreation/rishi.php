<?php
$php_var = "hello from php" ;
 
?>

<html>
<title></title>
<script language="javascript">
var java_code =  <?php echo json_encode($php_var);?> ;  //json encode use krna jaruri hai

alert(java_code) ; //for alert

</script>
</html>